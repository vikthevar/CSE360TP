package guiGraderDashboard;

import java.sql.*;
import java.util.*;
import database.DatabaseHelper; // Adjust to match your actual DB helper import

/**
 * <p> Title: GraderDashboardDataStore </p>
 *
 * <p> Description: Provides data access methods for the Grader Dashboard.
 * Queries activity trends, low-participation threads, and individual
 * student profiles from the database. Follows the existing project
 * pattern of dedicated store classes per GUI package. </p>
 */
public class GraderDashboardDataStore {

    private static GraderDashboardDataStore instance = null;
    private Connection connection;

    /** Private constructor for Singleton pattern */
    private GraderDashboardDataStore() {
        connection = DatabaseHelper.getConnection(); // Adjust to your DB connection method
    }

    /** Returns the single instance of this store */
    public static GraderDashboardDataStore getInstance() {
        if (instance == null) {
            instance = new GraderDashboardDataStore();
        }
        return instance;
    }

    // -------------------------------------------------------------------------
    // Activity Trends
    // -------------------------------------------------------------------------

    /**
     * Returns the number of discussion posts per day for the last N days.
     * Map key = date string (e.g. "2024-04-15"), value = post count.
     */
    public Map<String, Integer> getActivityTrends(int lastNDays) {
        Map<String, Integer> trends = new LinkedHashMap<>();
        String sql = "SELECT DATE(created_at) AS day, COUNT(*) AS cnt " +
                     "FROM DiscussionPosts " +
                     "WHERE created_at >= DATE('now', '-" + lastNDays + " days') " +
                     "GROUP BY day ORDER BY day ASC";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                trends.put(rs.getString("day"), rs.getInt("cnt"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return trends;
    }

    /**
     * Returns total posts in the last 7 days (summary stat).
     */
    public int getTotalPostsLastWeek() {
        String sql = "SELECT COUNT(*) FROM DiscussionPosts " +
                     "WHERE created_at >= DATE('now', '-7 days')";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    /**
     * Returns number of unique active students in the last 7 days.
     */
    public int getActiveStudentsLastWeek() {
        String sql = "SELECT COUNT(DISTINCT user_id) FROM DiscussionPosts " +
                     "WHERE created_at >= DATE('now', '-7 days')";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // -------------------------------------------------------------------------
    // Low-Participation Threads
    // -------------------------------------------------------------------------

    /**
     * Returns threads with fewer than the given reply threshold.
     * Each entry: [threadId, threadTitle, replyCount, createdAt]
     */
    public List<String[]> getLowParticipationThreads(int replyThreshold) {
        List<String[]> threads = new ArrayList<>();
        String sql = "SELECT t.id, t.title, COUNT(p.id) AS reply_count, t.created_at " +
                     "FROM DiscussionThreads t " +
                     "LEFT JOIN DiscussionPosts p ON p.thread_id = t.id " +
                     "GROUP BY t.id " +
                     "HAVING reply_count < ? " +
                     "ORDER BY reply_count ASC, t.created_at DESC";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, replyThreshold);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    threads.add(new String[]{
                        rs.getString("id"),
                        rs.getString("title"),
                        String.valueOf(rs.getInt("reply_count")),
                        rs.getString("created_at")
                    });
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return threads;
    }

    // -------------------------------------------------------------------------
    // Student Profiles
    // -------------------------------------------------------------------------

    /**
     * Returns a summary list of all students.
     * Each entry: [userId, userName, email, totalPosts, lastActive]
     */
    public List<String[]> getAllStudentSummaries() {
        List<String[]> students = new ArrayList<>();
        String sql = "SELECT u.id, u.username, u.email, " +
                     "COUNT(p.id) AS total_posts, MAX(p.created_at) AS last_active " +
                     "FROM Users u " +
                     "LEFT JOIN DiscussionPosts p ON p.user_id = u.id " +
                     "WHERE u.role = 'student' " +
                     "GROUP BY u.id ORDER BY u.username ASC";
        try (PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                students.add(new String[]{
                    rs.getString("id"),
                    rs.getString("username"),
                    rs.getString("email"),
                    String.valueOf(rs.getInt("total_posts")),
                    rs.getString("last_active") != null ? rs.getString("last_active") : "Never"
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    /**
     * Returns detailed profile data for a single student.
     * Returns: [userId, userName, email, totalPosts, lastActive, threadsStarted]
     */
    public String[] getStudentProfile(String userId) {
        String sql = "SELECT u.id, u.username, u.email, " +
                     "COUNT(p.id) AS total_posts, MAX(p.created_at) AS last_active, " +
                     "(SELECT COUNT(*) FROM DiscussionThreads WHERE created_by = u.id) AS threads_started " +
                     "FROM Users u " +
                     "LEFT JOIN DiscussionPosts p ON p.user_id = u.id " +
                     "WHERE u.id = ? GROUP BY u.id";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new String[]{
                        rs.getString("id"),
                        rs.getString("username"),
                        rs.getString("email"),
                        String.valueOf(rs.getInt("total_posts")),
                        rs.getString("last_active") != null ? rs.getString("last_active") : "Never",
                        String.valueOf(rs.getInt("threads_started"))
                    };
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * Returns recent posts by a specific student.
     * Each entry: [postId, threadTitle, postContent, createdAt]
     */
    public List<String[]> getStudentRecentPosts(String userId, int limit) {
        List<String[]> posts = new ArrayList<>();
        String sql = "SELECT p.id, t.title, p.content, p.created_at " +
                     "FROM DiscussionPosts p " +
                     "JOIN DiscussionThreads t ON t.id = p.thread_id " +
                     "WHERE p.user_id = ? " +
                     "ORDER BY p.created_at DESC LIMIT ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.setInt(2, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    posts.add(new String[]{
                        rs.getString("id"),
                        rs.getString("title"),
                        rs.getString("content"),
                        rs.getString("created_at")
                    });
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return posts;
    }
}
